Vitor Ubukata, A00992498, vitor.ubukata@gmail.com
Kenneth deHeer-Amissah, A00309486, kendeheer64@gmail.com

Azure URL ADMIN: https://vitor-ken-ass2.azurewebsites.net
Azure URL CLIENT: https://vitor-ken-client-ass2.azurewebsites.net

Challenges: 
