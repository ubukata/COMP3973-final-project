export class Event {
    Date: string;
    StartTime: string;
    EndTime: string;
    ActivityType: string;
}