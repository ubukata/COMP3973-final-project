export class EventsByDate {
    Date: string;
    Events: Event[]
}